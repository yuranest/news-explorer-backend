// PUT /items/:itemId/likes
module.exports.likeItem = (req, res) => {
  ClothingItem.findByIdAndUpdate(
    req.params.itemId,
    { $addToSet: { likes: req.user._id } }, // avoid duplicates
    { new: true }
  )
    .orFail(() => {
      const error = new Error("Item not found");
      error.statusCode = ERROR_NOT_FOUND;
      throw error;
    })
    .then((item) => res.send(item))
    .catch((err) => {
      console.error(err);
      if (err.name === "CastError") {
        return res
          .status(ERROR_BAD_REQUEST)
          .send({ message: "Invalid item ID format" });
      }
      res.status(err.statusCode || ERROR_SERVER).send({ message: err.message });
    });
};

// DELETE /items/:itemId/likes
module.exports.dislikeItem = (req, res) => {
  ClothingItem.findByIdAndUpdate(
    req.params.itemId,
    { $pull: { likes: req.user._id } }, // remove user from likes array
    { new: true }
  )
    .orFail(() => {
      const error = new Error("Item not found");
      error.statusCode = ERROR_NOT_FOUND;
      throw error;
    })
    .then((item) => res.send(item))
    .catch((err) => {
      console.error(err);
      if (err.name === "CastError") {
        return res
          .status(ERROR_BAD_REQUEST)
          .send({ message: "Invalid item ID format" });
      }
      res.status(err.statusCode || ERROR_SERVER).send({ message: err.message });
    });
};
